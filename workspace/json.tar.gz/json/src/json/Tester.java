package json;

import java.sql.*;

public class Tester {

	public static void main(String[] args) {
		Tester fh = new Tester();
		fh.getlinenum();
	}
	public int getlinenum()
	{
		int lines=-1;
		Connection connect = Connect.GetConnection();
		try
		{
			
			Statement statement = connect.createStatement();
			ResultSet resultSet = statement.executeQuery("select event_type from log");
			resultSet.next();
			System.out.println(" * "+resultSet.getString(1));
			resultSet.next();
			System.out.println(" * "+resultSet.getString(1));
			//lines=resultSet.getInt("line");
		}
		catch(Exception ex)
		{
			System.out.println(ex);
			System.out.println("Error in getlinenum function");
		}
		finally
		{
			try {
				connect.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return lines;
	}

}
