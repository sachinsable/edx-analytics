package json;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.FileReader;
import java.io.BufferedReader;

public class Edxparser {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Edxparser edxp = new Edxparser();
		edxp.readfile();

	}
	
	public void readfile()
	{
		String path="/home/sachin/workspace/json/src/json/log/tracking.log";
		File flen = new File(path);
		long l = flen.length();
		System.out.println("current size"+l);
		FileReader fr;
		try {
			Database db = new Database();
			
			fr = new FileReader(path);
			BufferedReader textReader = new BufferedReader(fr);
			
			String line;
			int linenum=db.getlinenum();
			long ol=db.getsize();
			
			if(l>ol)
			{
				db.setsize(l);
	
				try
				{
					int i=1;
					LineParser lp = new LineParser();
					while((line=textReader.readLine())!=null)
					{
						if(i>linenum)
						{
							System.out.println(line);
							if(line.startsWith("{"))
							{
								lp.parseline(line);
								linenum++;
							}
						}
						i++;
					}
					System.out.println(db.insertlinenum(linenum)+" "+linenum+" "+db.getsize());
				}
				catch (IOException e)
				{
					e.printStackTrace();
				}
				finally
				{
					try
					{
						textReader.close();
					}
					catch (IOException e)
					{
						e.printStackTrace();
					}
				}
			}
			else if(l==ol)
			{
				System.out.println("File is not changed");
			}
			else
			{
				System.out.println("file might have been archived");
				Filehandler fh =new Filehandler();
				Edxparser ep = new Edxparser();
				fh.handlefile();
				ep.readfile();
			}
		}
		catch (FileNotFoundException e)
		{
			e.printStackTrace();
		}
	}
}